/*
MKS ESP32 FOC 闭环位置力矩互控 例程 测试库：SimpleFOC 2.2.1 测试硬件：MKS ESP32 FOC V1.0
上电后转动其中一个电机，另一个电机也会跟随，两个电机时刻保持位置力矩互控
在使用自己的电机时，请一定记得修改默认极对数，即 BLDCMotor(7) 中的值，设置为自己的极对数数字
程序默认设置的供电电压为 12V,用其他电压供电请记得修改 voltage_power_supply , voltage_limit 变量中的值
默认PID针对的电机是 2804云台电机 ，使用的编码器是AS5600，使用自己的电机需要修改PID参数，才能实现更好效果
 */
 
#include <SimpleFOC.h>


MagneticSensorI2C sensor = MagneticSensorI2C(AS5600_I2C);
MagneticSensorI2C sensor1 = MagneticSensorI2C(AS5600_I2C);
TwoWire I2Cone = TwoWire(0);
TwoWire I2Ctwo = TwoWire(1);

// Motor instance
BLDCMotor motor = BLDCMotor(7);                             //根据选用的电机，修改极对数，即BLDCMotor()中的值
BLDCDriver3PWM driver = BLDCDriver3PWM(32, 33, 25, 22);

BLDCMotor motor1 = BLDCMotor(7);
BLDCDriver3PWM driver1 = BLDCDriver3PWM(26, 27, 14, 12);    //同样修改此处BLDCMotor()的值

//I2C初始化
void I2C_init();

void setup() {
  I2C_init();
 
  // driver config
  // power supply voltage [V]
  driver.voltage_power_supply = 12;               //根据供电电压，修改此处voltage_power_supply的值
  driver.init();

  driver1.voltage_power_supply = 12;              //同样修改此处voltage_power_supply的值
  driver1.init();
  // link the motor and the driver
  motor.linkDriver(&driver);
  motor1.linkDriver(&driver1);
  
  // set motion control loop to be used
  motor.controller = MotionControlType::torque;
  motor1.controller = MotionControlType::torque;

  // maximal voltage to be set to the motor
  motor.voltage_limit = 1;[V]                       //请尽量避免修改此数值，过大的电压电流可能会导致驱动板被烧坏
  motor1.voltage_limit = 1;[V]                      //请尽量避免修改此数值，过大的电压电流可能会导致驱动板被烧坏
  Serial.begin(115200);
  // comment out if not needed
  motor.useMonitoring(Serial);
  motor1.useMonitoring(Serial);
  delay(1000);
  //初始化电机
  motor.init();
  delay(1000);
  motor1.init();
  delay(500);
  motor.initFOC();
  delay(500);
  motor1.initFOC();


  Serial.println("Motor ready.");
  _delay(1000);
  
}

void loop() {

  motor.loopFOC();
  motor1.loopFOC();

  motor.move( 5*(motor1.shaft_angle - motor.shaft_angle));
  motor1.move( 5*(motor.shaft_angle - motor1.shaft_angle));
}

float dead_zone(float x){
  return abs(x) < 0.2 ? 0 : x;
}

void I2C_init(){
  pinMode(32, INPUT_PULLUP);
  pinMode(33, INPUT_PULLUP);
  pinMode(25, INPUT_PULLUP);
  pinMode(26, INPUT_PULLUP);
  pinMode(27, INPUT_PULLUP);
  pinMode(14, INPUT_PULLUP);

  I2Cone.begin(19,18, 400000UL); 
  I2Ctwo.begin(23,5, 400000UL);
  sensor.init(&I2Cone);
  sensor1.init(&I2Ctwo);
  //连接motor对象与传感器对象
  motor.linkSensor(&sensor);
  motor1.linkSensor(&sensor1);
}
