// MKS ESP32 FOC V2.0 电流闭环速度控制例程 测试库：SimpleFOC 2.2.1 测试硬件：MKS ESP32 FOC V2.0 & MKS AS5600

// ！！！注意事项！！！
// ①串口中输入"A+数字"设定M0电机转动的速度，例如输入“A10”，则是将M0电机的转速设置为10rad/s，输入“B+数字”设定M1电机转动的速度；
// ②在使用自己的电机时，请一定记得修改默认极对数，即 BLDCMotor(7) 中的值，设置为自己电机的极对数；
// ③请根据选用电机设置正确的 voltage_limit和current_limit的值，建议航模电机设置在0.5~1.0之间，云台电机设置在4以下，过大电压电流可能导致烧坏驱动板！
// ④该例程的pid参数可控制2808航模电机，如果想要实现更好的效果或使用其他电机，请自行调整pid参数

#include <SimpleFOC.h>

//电机实例
BLDCMotor motor1 = BLDCMotor(7);
BLDCDriver3PWM driver1 = BLDCDriver3PWM(32, 33, 25, 12);

BLDCMotor motor2 = BLDCMotor(7);
BLDCDriver3PWM driver2 = BLDCDriver3PWM(26, 27, 14, 12);

//编码器实例
MagneticSensorI2C sensor1 = MagneticSensorI2C(AS5600_I2C);
TwoWire I2Cone = TwoWire(0);
MagneticSensorI2C sensor2 = MagneticSensorI2C(AS5600_I2C);
TwoWire I2Ctwo = TwoWire(1);

// 在线电流检测实例
InlineCurrentSense current_sense1 = InlineCurrentSense(0.01, 50.0, 39, 36);
InlineCurrentSense current_sense2 = InlineCurrentSense(0.01, 50.0, 35, 34);

// commander通信实例
Commander command = Commander(Serial);
void doMotor1(char* cmd) {
  command.motor(&motor1, cmd);
}
void doMotor2(char* cmd) {
  command.motor(&motor2, cmd);
}

//设置报警电压
#define UNDERVOLTAGE_THRES 11.1
void board_init();
float get_vin_Volt();

void setup() {
  Serial.begin(115200);
  board_init();

  // 编码器设置
  I2Cone.begin(19, 18, 400000UL); // AS5600_M0
  I2Ctwo.begin(23, 5, 400000UL); // AS5600_M1
  sensor1.init(&I2Cone);
  sensor2.init(&I2Ctwo);

  //连接motor对象与传感器对象
  motor1.linkSensor(&sensor1);
  motor2.linkSensor(&sensor2);

  // 驱动器设置
  driver1.voltage_power_supply = get_vin_Volt();
  driver1.init();
  motor1.linkDriver(&driver1);
  driver2.voltage_power_supply = get_vin_Volt();
  driver2.init();
  motor2.linkDriver(&driver2);

  // 电流限制
  motor1.current_limit = 0.5;
  motor2.current_limit = 0.5;

  // 电压限制
  motor1.voltage_limit = 0.5;
  motor2.voltage_limit = 0.5;


  // 电流检测
  current_sense1.init();
  // current_sense1.gain_b *= 1;
  // current_sense1.gain_a *= 1;
  //  current_sense1.skip_align = true;
  motor1.linkCurrentSense(&current_sense1);

  // current sense init and linking
  current_sense2.init();
  // current_sense2.gain_b *= 1;
  // current_sense2.gain_a *= 1;
  //  current_sense2.skip_align = true;
  motor2.linkCurrentSense(&current_sense2);

  // 控制环
  // 其他模式 TorqueControlType::voltage TorqueControlType::dc_current
  motor1.torque_controller = TorqueControlType::foc_current;
  motor1.controller = MotionControlType::velocity;
  motor2.torque_controller = TorqueControlType::foc_current;
  motor2.controller = MotionControlType::velocity;

  motor1.voltage_sensor_align = 5;
  motor2.voltage_sensor_align = 5;

  // FOC电流控制PID参数
  motor1.PID_current_q.P = 1;
  motor1.PID_current_q.I = 500;
  motor1.PID_current_d.P = 1;
  motor1.PID_current_d.I = 500;
  motor1.LPF_current_q.Tf = 0.002;  // 1ms default
  motor1.LPF_current_d.Tf = 0.002;  // 1ms default

  motor2.PID_current_q.P = 1;
  motor2.PID_current_q.I = 500;
  motor2.PID_current_d.P = 1;
  motor2.PID_current_d.I = 500;
  motor2.LPF_current_q.Tf = 0.002;  // 1ms default
  motor2.LPF_current_d.Tf = 0.002;  // 1ms default

  // 速度环PID参数
  motor1.PID_velocity.P = 0.021;
  motor1.PID_velocity.I = 0.12;
  motor1.PID_velocity.D = 0;

  motor2.PID_velocity.P = 0.021;
  motor2.PID_velocity.I = 0.12;
  motor2.PID_velocity.D = 0;
  // default voltage_power_supply

  // 速度限制
  motor1.velocity_limit = 20;
  motor2.velocity_limit = 20;

  // monitor接口设置
  // comment out if not needed
  motor1.useMonitoring(Serial);
  motor2.useMonitoring(Serial);

  // monitor相关设置
  motor1.monitor_downsample = 0;
  motor1.monitor_variables = _MON_TARGET | _MON_VEL | _MON_ANGLE | _MON_CURR_Q;
  motor2.monitor_downsample = 0;
  motor2.monitor_variables = _MON_TARGET | _MON_VEL | _MON_ANGLE | _MON_CURR_Q;

  //电机初始化
  motor1.init();
  // align encoder and start FOC
  motor1.initFOC();

  motor2.init();
  // align encoder and start FOC
  motor2.initFOC();

  // 初始目标值
  motor1.target = 0.0;
  motor2.target = 0.0;

  // 映射电机到commander
  command.add('A', doMotor1, "motor 1");
  command.add('B', doMotor2, "motor 2");

  Serial.println(F("Double motor sketch ready."));

  _delay(1000);
}


void loop() {
  motor1.loopFOC();
  motor2.loopFOC();

  motor1.move();
  motor2.move();

  command.run();
}

void board_init() {
  pinMode(32, INPUT_PULLUP);
  pinMode(33, INPUT_PULLUP);
  pinMode(25, INPUT_PULLUP);
  pinMode(26, INPUT_PULLUP);
  pinMode(27, INPUT_PULLUP);
  pinMode(14, INPUT_PULLUP);

  analogReadResolution(12);  //12bit

  float VIN_Volt = get_vin_Volt();
  while (VIN_Volt <= UNDERVOLTAGE_THRES) {
    VIN_Volt = get_vin_Volt();
    delay(100);
    Serial.printf("等待上电,当前电压%.2f\n", VIN_Volt);
  }
  Serial.printf("正在校准电机...当前电压%.2f\n", VIN_Volt);
}

float get_vin_Volt() {
  return analogReadMilliVolts(13) * 8.5 / 1000;
}
